#Requires -Version 7.2 

function Get-NcalRow {
    <# 
        .NOTES
        Helper function for Get-NCalendar. Prints one row of calendar output, given an Index corresponding to the
        first day of the month.
    #>
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Mandatory, Position = 1)]
        #[ValidateRange(-5, 1)]
        [Int]$Index,
        
        [Parameter(Position = 2)]
        [ValidateRange(28, 31)]
        [Int]$DayPerMonth,

        [Parameter(Position = 3)]
        [ValidateRange(1, 12)]
        [Int]$Month,

        [Parameter(Position = 4)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [Parameter(Position = 5)]
        [Object]$Highlight,

        [Parameter(Position = 6)]
        [Bool]$JulianSpecified
    ) 

    begin {
        $WeekDay = $Index
        $Row = ''
        $JulianDay = 0

        if ($JulianSpecified) {
            $PadRow = 24
            $PadDay = 3
        }
        else {
            $PadRow = 19
            $PadDay = 2
        }
    }

    process {
        do {
            if ($WeekDay -lt 1) {
                $Row += "{0,$PadDay} " -f $null
            }
            else {
                if ($JulianSpecified) {
                    try {
                        $ThisDate = '{0:D2}/{1:D2}/{2}' -f $WeekDay, $Month, $Year
                        $UseDate = [datetime]::ParseExact($ThisDate, 'dd/MM/yyyy', $Culture)
                        $JulianDay = $Culture.Calendar.GetDayOfYear($UseDate)
                        $Row += "{0,$PadDay} " -f $JulianDay
                    }
                    catch {
                        Write-Error "day beyond day/month - $($_.Message)"
                    }
                }
                else {
                    $Row += "{0,$PadDay} " -f $WeekDay
                }
            }
            $WeekDay += 7
        }
        until ($WeekDay -gt $DayPerMonth)
        $OutString = "$($Row.TrimEnd())".PadRight($PadRow, ' ')
        <#
            The secret to not screwing up formatted strings with non-printable characters is to mess with the string 
            after the string is padded to the right length.
        #>
        if ( ($Highlight.Today -gt 0) -and $JulianSpecified) {
            $ThisDate = '{0:D2}/{1:D2}/{2}' -f $Highlight.Today, $Month, $Year
            $UseDate = [datetime]::ParseExact($ThisDate, 'dd/MM/yyyy', $Culture)
            $JulianDay = $Culture.Calendar.GetDayOfYear($UseDate)
        
            if ($OutString -match "\b$JulianDay\b") {
                $OutString = $OutString -replace "$JulianDay\b", "$($Highlight.DayStyle)$JulianDay$($Highlight.DayReset)"
            }
        }
        elseif ( ($Highlight.Today -gt 0) -and ($OutString -match "\b$($Highlight.Today)\b")) {
            if ($Highlight.Today -lt 10) {
                $OutString = $OutString -replace "\s$($Highlight.Today)\b", "$($Highlight.DayStyle) $($Highlight.Today)$($Highlight.DayReset)"
            }
            else {
                $OutString = $OutString -replace "$($Highlight.Today)\b", "$($Highlight.DayStyle)$($Highlight.Today)$($Highlight.DayReset)"
            }
        }
        Write-Output $OutString
    }
}

function Get-CalRow {
    <#
    .NOTES
    Helper function for Get-Calendar - Prints one row of calendar output, given an Index corresponding to the 
    first day of the month.
#>
    param (
        [Parameter(Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Position = 1)]
        #[ValidateRange(-5, 1)]
        [Int]$Index,
        
        [Parameter(Position = 2)]
        [ValidateRange(28, 31)]
        [Int]$DayPerMonth,

        [Parameter(Position = 3)]
        [ValidateRange(1, 12)]
        [Int]$Month,

        [Parameter(Position = 4)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [Parameter(Position = 5)]
        [Object]$Highlight,

        [Parameter(Position = 6)]
        [Bool]$JulianSpecified
    ) 

    begin {
        $WeekDay = $Index
        $Row = ''
        $JulianDay = 0

        if ($JulianSpecified) {
            $PadRow = 29
            $PadDay = 3
        }
        else {
            $PadRow = 22
            $PadDay = 2
        }
    }

    process {
        # Repeat 7 times for each week day in the row 
        0..6 | ForEach-Object {
            if ($WeekDay -lt 1) {
                $Row += "{0,$PadDay} " -f $null
            }
            elseif ($WeekDay -gt $DayPerMonth) {
                #do nothing
            }
            else {
                if ($JulianSpecified) {
                    try {
                        $ThisDate = '{0:D2}/{1:D2}/{2}' -f $WeekDay, $Month, $Year
                        $UseDate = [datetime]::ParseExact($ThisDate, 'dd/MM/yyyy', $Culture)
                        $JulianDay = $Culture.Calendar.GetDayOfYear($UseDate)
                        $Row += "{0,$PadDay} " -f $JulianDay
                    }
                    catch {
                        Write-Error "day beyond day/month - $($_.Message)"
                    }
                }
                else {
                    $Row += "{0,$PadDay} " -f $WeekDay
                }
            }
            $WeekDay++
        }
        $OutString = "$($Row.TrimEnd())".PadRight($PadRow, ' ')
    
        <#
            The secret to not screwing up formatted strings with non-printable characters is to mess with the 
            string after the string is padded to the right length.
        #>
        if ( ($Highlight.Today -gt 0) -and $JulianSpecified) {
            $ThisDate = '{0:D2}/{1:D2}/{2}' -f $Highlight.Today, $Month, $Year
            $UseDate = [datetime]::ParseExact($ThisDate, 'dd/MM/yyyy', $Culture)
            $JulianDay = $Culture.Calendar.GetDayOfYear($UseDate)
        
            if ($OutString -match "\b$JulianDay\b") {
                $OutString = $OutString -replace "$JulianDay\b", "$($Highlight.DayStyle)$JulianDay$($Highlight.DayReset)"
            }
        }
        elseif ( ($Highlight.Today -gt 0) -and ($OutString -match "\b$($Highlight.Today)\b")) {
            if ($Highlight.Today -lt 10) {
                $OutString = $OutString -replace "\s$($Highlight.Today)\b", "$($Highlight.DayStyle) $($Highlight.Today)$($Highlight.DayReset)"
            }
            else {
                $OutString = $OutString -replace "$($Highlight.Today)\b", "$($Highlight.DayStyle)$($Highlight.Today)$($Highlight.DayReset)"
            }
        }
        Write-Output $OutString
    }
}

function Get-Today {
    [CmdletBinding()]
    param (
        [System.Globalization.CultureInfo]$Culture
    )
    process {
        $Now = Get-Date
        [PSCustomObject]@{
            'Year'  = $Culture.Calendar.GetYear($Now)
            'Month' = $Culture.Calendar.GetMonth($Now)
            'Day'   = $Culture.Calendar.GetDayOfMonth($Now)
        }
    }
}

function Get-MonthHeading {
    <# 
        .NOTES
        Helper function for Get-NCalendar and Get-Calendar. Returns a string.
    #>
    param (
        [Parameter(Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Position = 1)]
        [String]$MonthName,

        [Parameter(Position = 2)]
        [Bool]$JulianSpecified
    )

    begin {
        $CallStack = Get-PSCallStack
        if ($CallStack.Count -gt 1) {
            $CallingFunction = $CallStack[1].Command
        }
    }
    process {
        if ($CallingFunction -eq 'Get-Calendar') {
            if ($true -eq $JulianSpecified) {
                $HeadingLength = 29
            }
            else {
                $HeadingLength = 22
            }
            # Special cases - resorted to hard coding for double width character sets like Kanji.
            # Japanese, traditional Chinese and Korean have 1 double width character in month name, simplified Chinese 
            # and Yi have two. This is a rough hack, but it works.
            if ($Culture.Name -match '^(ja|zh-hant|ko$|ko\-)') { $HeadingLength -= 1 }
            if ($Culture.Name -match '^(zh$|zh-hans|ii)') { $HeadingLength -= 2 }
        
            # Heading length also contains additional 2 space padding, so take this into account when centering
            # Note: Padright on RTL languages makes no difference
            $Pad = $MonthName.Length + (($HeadingLength - 2 - $MonthName.Length) / 2)
            $MonthHeading = ($MonthName.PadLeft($Pad, ' ')).PadRight($HeadingLength, ' ')

        }
        # This is for ncal
        else {
            if ($true -eq $JulianSpecified) {
                $Pad = 24
            }
            else {
                $Pad = 19
            }
            # Special cases - resorted to hard coding for double width characters
            # Japanese, traditional Chinese and Korean have 1 double width character in month name, simplified Chinese 
            # and Yi have two. This is a rough hack, but it works.
            if ($Culture.Name -match '^(ja|zh-hant|ko$|ko\-)') { $Pad -= 1 }
            if ($Culture.Name -match '^(zh$|zh-hans|ii)') { $Pad -= 2 }
            $MonthHeading = "$MonthName".PadRight($Pad, ' ')
        }
        Write-Output $MonthHeading
        #Write-Verbose "|$MonthHeading| Length = $($MonthHeading.Length)"
    }
}

function Get-FirstDayOfMonth {
    <# 
        .NOTES
        Helper function for Get-NCalendar and Get-Calendar that returns the date and day name of the first day of each 
        required month, using the specified culture. This function performs the paramters validation for both ncal and
        cal.

        Note to self - the thing to remember when using different cultures is that once you've determined the
        correct date in the required culture, you parse this to create a date object. Because we're not messing 
        with the default system culture here, the date objects returned by this function will appear in the local 
        culture. So non-Gregorian culture dates, like Persian, will look funky.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Globalization.CultureInfo]$Culture,
        
        # Could be an integer between 1 and 12 or same with an f or p suffix
        [Parameter(Position = 1)]
        [String]$Month,
        
        [Parameter(Position = 2)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [Parameter(Position = 3)]
        [Int]$Before,
        
        [Parameter(Position = 4)]
        [Int]$After,

        [Parameter(Position = 5)]
        [Switch]$Three
    )

    process {
        # Todays date in specified culture
        $Now = Get-Today -Culture $Culture

        if ($PSBoundParameters.ContainsKey('Month')) {
            [Int]$AfterOffset = 0

            if ($PSBoundParameters.ContainsKey('Year')) { 
                $YearSpecified = $true
            }
            else {
                $Year = $Now.Year
                $YearSpecified = $false
            }

            if ($Month -in 1..12) {
                [Int]$MonthNumber = $Month
            }
            # trailing 'f' means month specified, but next year required
            elseif ($Month -match '^(0?[1-9]|1[0-2])[Ff]$') {
                [Int]$MonthNumber = ($Month | Select-String -Pattern '^\d+').Matches.Value
                $Year += 1
            }
            # trailing 'p' means month specified, but last year required
            elseif ($Month -match '^(0?[1-9]|1[0-2])[Pp]$') {
                [Int]$MonthNumber = ($Month | Select-String -Pattern '^\d+').Matches.Value
                $Year -= 1
            }
            else {
                Write-Error "ncal: '$Month' is neither a month number (1..12) nor a valid month name (using the current culture)"
                return
            }
        }
        else {
            # No month
            if ($PSBoundParameters.ContainsKey('Year')) {
                # Year specified with no month; showing whole year
                [Int]$MonthNumber = 1
                [Int]$BeforeOffset = 0
                [Int]$AfterOffset = 11
                $YearSpecified = $true
            }
            else {
                # Default is this month only
                $MonthNumber = $Now.Month
                $Year = $Now.Year
                $YearSpecified = $false
            }
        }

        # add additional month before and after current month.
        if ($PSBoundParameters.ContainsKey('Three')) {
            [Int]$BeforeOffset = 1
            [Int]$AfterOffset = 1
        }
        # add specified number of months before the month or year already identified
        if ($PSBoundParameters.ContainsKey('Before')) {
            $BeforeOffset += $Before
        }
        # add specified number of months following the month(s) or year already identified
        if ($PSBoundParameters.ContainsKey('After')) {
            $AfterOffset += $After
        }

        # special case for ar-sa (Arabic, Saudi Arabia)
        if ($Culture.Name -match '^(ar-SA)$' -and ($Year -lt 1318 -or $Year -gt 1500)) {
            write-verbose $Year
            Write-Error 'The UmAlQura calendar (Saudi Arabia) is only supported for years 1318 to 1500.'
            return
        }

        # Parameter validation complete. We have the required months to show, and a target month (typically this
        # month or possibly first month of required year). Determine the date of the first day of target month
        # and then use this to determine the date of the first day of the first required month.
        $MonthCount = 1 + $BeforeOffset + $AfterOffset
        $DateString = '{0}/{1:D2}/{2}' -f '01', $MonthNumber, $Year # ParseExact expects 2 digit day and month
        $TargetDate = [datetime]::ParseExact($DateString, 'dd/MM/yyyy', $Culture)
        $FirstDay = $Culture.Calendar.AddMonths($TargetDate, - $BeforeOffset)
    
        for ($i = 1; $i -le $MonthCount; $i++) {
            $ThisYear = $Culture.Calendar.GetYear($FirstDay)
            $ThisMonth = $Culture.Calendar.GetMonth($FirstDay)
            $DayPerMonth = $Culture.Calendar.GetDaysInMonth($ThisYear, $ThisMonth)
            [pscustomobject] @{
                'Date'          = $FirstDay # illustrates funky looking date when shown in local culture
                'Year'          = $ThisYear
                'Month'         = $ThisMonth
                'Day'           = $Culture.Calendar.GetDayOfMonth($FirstDay) # for clarity, not used
                'FirstDay'      = $Culture.Calendar.GetDayOfWeek($FirstDay) # for clarity, not used
                'FirstDayIndex' = $Culture.Calendar.GetDayOfWeek($FirstDay).value__ # Monday=1, Sunday=7
                'DayPerMonth'   = $DayPerMonth
                'YearSpecified' = $YearSpecified # Used to determine year and month headings
            }
            $FirstDay = $Culture.Calendar.AddMonths($FirstDay, 1)
        }
    }
}

function Get-StartWeekIndex {
    <#
        .NOTES
        The first day index is always 1 through 7, Monday to Sunday. This function returns an index, based on the 
        real/desired first day of the week and the actual start day. This will be a number between -5 and 1. When 
        we reach an index=1, we start printing (Get-Ncal/Get-Cal), otherwise we print a space.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Mandatory, Position = 1)]
        [ValidateSet('Friday', 'Saturday', 'Sunday', 'Monday')]
        [string]$StartWeekDay,

        [Int]$FirstDayIndex
    )

    process {
        # Monday = -2 thru Sunday = -8, which means Friday-Sunday start on next column so force 1, 0, -1 resp.
        if ('Friday' -eq $StartWeekDay) {
            $ThisIndex = -1 - $FirstDayIndex
            if ($ThisIndex -eq -6) {
                $ThisIndex = 1
            }
            elseif ($ThisIndex -eq -7) {
                $ThisIndex = 0
            }
            elseif ($ThisIndex -eq -8) {
                $ThisIndex = -1
            }
        }
        # Monday = -1 thru Sunday = -7 which mean both Saturday and Sunday start on next column, so force 1 and 0 resp.
        elseif ('Saturday' -eq $StartWeekDay) {
            $ThisIndex = 0 - $FirstDayIndex
            if ($ThisIndex -eq -6) {
                $ThisIndex = 1
            }
            elseif ($ThisIndex -eq -7) {
                $ThisIndex = 0
            }
        }
        elseif ('Sunday' -eq $StartWeekDay) {
            # Monday = 0 thru Sunday = -6, which would mean start on next column, so force Sunday to be 1
            $ThisIndex = 1 - $FirstDayIndex
            if ($ThisIndex -eq -6) {
                $ThisIndex = 1
            }
        }
        else {
            # Week starts Monday. Here we need Monday = 1 thru Sunday = -5
            $ThisIndex = 2 - $FirstDayIndex
            if ($ThisIndex -eq 2) {
                $ThisIndex = -5
            }
        }
        Write-Output $ThisIndex
    }
}

function Get-WeekDayName {
    <#
        .NOTES
        Determine the localized week day names. There are globalisation issues with attempting to truncate day 
        names in some cultures, so only truncate cultures with standard character sets.

        For ncal only, MonthOffset is an attempt to fix column formats with many cultures that have mixed length 
        short and long day names. It seems to work ok providing an appropriate font is installed supporting unicode 
        characters.

        According .Net, just one language (Dhivehi - cultures dv and dv-MV), spoken in Maldives, has a week day 
        starting on Friday. Most Islamic countries (some Arabic, Persian, Pashto and one or two others) use 
        Saturday. All Western and Eastern European countries, Russia, Indian, Asian-Pacific countries, except China 
        and Japan follow ISO 1806 standard with Monday as the first day of the week. All North and South American 
        countries, China and Japan use Sunday.

        With ncal, we want full day names or abbreviated day names (modified for some cultures).
        With cal, we want abbreviated names (shortened for some cultures) or the shortest day names.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Mandatory, Position = 1)]
        [ValidateSet('Friday', 'Saturday', 'Sunday', 'Monday')]
        [string]$FirstDayOfWeek,

        [Parameter(Position = 2)]
        [Switch]$LongDayName,

        [Parameter(Position = 3)]
        [Switch]$JulianSpecified
    )

    begin {
        $CallStack = Get-PSCallStack
        if ($CallStack.Count -gt 1) {
            $CallingFunction = $CallStack[1].Command
        }
    }
    process {
        if ($CallingFunction -eq 'Get-Calendar') {
            # Truncate some Abbreviated day names to two characters (e.g. Mo, Tu), rather than Shortest day names (e.g. M, T)
            # for some Western languages.
            if ($Culture.Name -match '^(ja|zh|ko$|ko\-|ii)') {
                # Some cultures use double width character sets. So attempt to capture these and do not pad day names
                $WeekDay = $Culture.DateTimeFormat.ShortestDayNames
                if ($true -eq $JulianSpecified) {
                    # For day of the year, each day is 2 characters wide with double-width character sets.
                    $WeekDay = $WeekDay | ForEach-Object { "$_".PadLeft(2, ' ') }
                }
            }
            else {
                if ($Culture.Name -match '^(da|de|es|eo|en|fr|it|pt)') {
                    $WeekDay = $Culture.DateTimeFormat.AbbreviatedDayNames | ForEach-Object { "$_".Substring(0, 2) }
                }
                else {
                    # Quite a lot of cultures use a single character, so ensure the names are 2 characters.
                    $WeekDay = $Culture.DateTimeFormat.ShortestDayNames | ForEach-Object { "$_".PadLeft(2, ' ') }
                }
                if ($true -eq $JulianSpecified) {
                    # For day of the year, each day is 3 characters wide.
                    $WeekDay = $WeekDay | ForEach-Object { "$_".PadLeft(3, ' ') }
                }
            }
            Write-Verbose "Short week day - $WeekDay"
        }
        else {
            # Get-NCalendar is the (default) calling function
            if ($true -eq $LongDayName) {
                $WeekDayLong = $Culture.DateTimeFormat.DayNames
                Write-Verbose "Long week day - $WeekDayLong"
                if ($Culture.Name -match '^(ja|zh|ko$|ko\-|ii)') {
                    # Full day name for cultures that use double width character sets, double the size of the month offset but not the weekday  
                    $MonthOffset = 2 + ((($WeekDayLong | ForEach-Object { "$_".Length } | Measure-Object -Maximum).Maximum) * 2)
                    $WeekDayLength = ($WeekDayLong | ForEach-Object { "$_".Length } | Measure-Object -Maximum).Maximum
                    $WeekDay = $WeekDayLong | ForEach-Object { "$_".PadRight($WeekDayLength + 1, ' ') }
                }
                else {
                    # Full day name for cultures using latin and Persian character sets.
                    $MonthOffset = 2 + (($WeekDayLong | ForEach-Object { "$_".Length } | Measure-Object -Maximum).Maximum)
                    $WeekDay = $WeekDayLong | ForEach-Object { "$_".PadRight($MonthOffset - 1, ' ') }
                }
            }
            else {
                $WeekDayShort = $Culture.DateTimeFormat.AbbreviatedDayNames
                Write-Verbose "Abbreviated week day - $WeekDayShort"
                if ($Culture.Name -match '^(ja|zh|ko$|ko\-|ii)') {
                    # Short day names for cultures that use double width character sets
                    $MonthOffset = 2 + ((($WeekDayShort | ForEach-Object { "$_".Length } | Measure-Object -Maximum).Maximum) * 2)
                    $WeekDayLength = ($WeekDayShort | ForEach-Object { "$_".Length } | Measure-Object -Maximum).Maximum
                    $WeekDay = $WeekDayShort | ForEach-Object { "$_".PadRight($WeekDayLength + 1, ' ') }
                }
                elseif ($ThisCulture.Name -match '^(en|fr|de|it|es|pt|eo)') {
                    # Simulate the Linux ncal command with two character day names on some Western cultures.
                    $MonthOffset = 4
                    $WeekDay = $WeekDayShort | ForEach-Object { "$_".Substring(0, 2).PadRight(3, ' ') }
                }
                else {
                    # Short day name for all other cultures. 
                    $MonthOffset = 2 + (($WeekDayShort | ForEach-Object { "$_".Length } | Measure-Object -Maximum).Maximum)
                    $WeekDay = $WeekDayShort | ForEach-Object { "$_".PadRight($MonthOffset - 1, ' ') }
                }
            }
        }

        Write-Verbose "Specified/assumed First day of week is $FirstDayOfWeek"
        Write-Verbose "Cultural First day of week is $($Culture.DateTimeFormat.FirstDayOfWeek)"

        # DayNames and AbbreviatedDayNames properties in .Net are always Sunday based, regardless of culture.
        if ('Friday' -eq $FirstDayOfWeek) {
            $WeekDay = $WeekDay[5, 6, 0, 1, 2, 3, 4]
        }
        if ('Saturday' -eq $FirstDayOfWeek) {
            $WeekDay = $WeekDay[6, 0, 1, 2, 3, 4, 5]
        }
        elseif ('Monday' -eq $FirstDayOfWeek) {
            $WeekDay = $WeekDay[1, 2, 3, 4, 5, 6, 0]
        }
        [PSCustomObject]@{
            Name   = $WeekDay
            Offset = $MonthOffset
        }
    }
}

function Get-WeekRow {
    <#
        .NOTES
        Helper function for Get-NCalendar. Prints the week number to display beneath each column

        Uses a .Net call to obtain the week number for the first week of the month for the required culture. We use 
        the specified first day of the week to ensure the week numbers align (although this is not culturally 
        correct). Otherwise, we are using the default first day of the week for the required culture.
        
        The other thing we're doing is ensuring the correct number of week numbers per month. Most of the time,
        this is five columns. However, if the first day of the month appears in the last day of the week position 
        and there are 30 or 31 days in the month, then there are 6 columns. If it appears in the next to last 
        position, and there 31 days, then are 6 columns. This equates to Index = -5 or -4 respectively.  

        The only other combination is when there are 28 days in February, and the first day is position 1 (Index = 1).
        In this case, there are only 4 columns.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Mandatory, Position = 1)]
        [ValidateRange(1, 12)]
        [Int]$Month,

        [Parameter(Mandatory, Position = 2)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [Parameter(Mandatory, Position = 3)]
        [ValidateSet('Friday', 'Saturday', 'Sunday', 'Monday')]
        [String]$FirstDayOfWeek,

        [Parameter(Mandatory, Position = 3)]
        [ValidateRange(-5, 1)]
        [Int]$Index,

        [Parameter(Position = 4)]
        [Bool]$JulianSpecified
    )

    process {
        $ThisDate = '{0}/{1:D2}/{2}' -f '01', $Month, $Year
        $FirstDate = [datetime]::ParseExact($ThisDate, 'dd/MM/yyyy', $Culture)
        $DayPerMonth = $Culture.Calendar.GetDaysInMonth($Year, $Month)
        $CultureWeekRule = $Culture.DateTimeFormat.CalendarWeekRule
        Write-Verbose "WeekRow - $Month, $Year, $Index"

        # Adjust the starting week number, based on the first day of the week.
        if ('Friday' -eq $FirstDayOfWeek) {
            $StartWeekDay = 5
        }
        if ('Saturday' -eq $FirstDayOfWeek) {
            $StartWeekDay = 6
        }
        elseif ('Sunday' -eq $FirstDayOfWeek) {
            $StartWeekDay = 0
        }
        elseif ('Monday' -eq $FirstDayOfWeek) {
            $StartWeekDay = 1
        }
        else {
            #can't be necessary, but use default for the requested culture, for illustration.
            $StartWeekDay = $Culture.DateTimeFormat.FirstDayOfWeek
        }
        # This is the starting week number of this month, taking into account the starting week day.
        $FirstWeek = $Culture.Calendar.GetWeekOfYear($FirstDate, $CultureWeekRule, $StartWeekDay)

        [String]$WeekRow = ''
        [Int]$WeekCount = 5

        if (-5 -eq $Index -and $DayPerMonth -ge 30) {
            $WeekCount = 6
        }
        elseif (-4 -eq $Index -and $DayPerMonth -gt 30) {
            $WeekCount = 6
        }
        elseif (1 -eq $Index -and $DayPerMonth -eq 28) {
            $WeekCount = 4
        }

        if ($true -eq $JulianSpecified) {
            $PadRow = 24
            $PadDay = 3
        }
        else {
            $PadRow = 19
            $PadDay = 2
        }

        $LastWeek = $FirstWeek + ($WeekCount - 1)
        $FirstWeek..$LastWeek | ForEach-Object {
            if ($_ -gt 52) {
                $WeekRow += "{0,$PadDay} " -f ($_ - 52)
            }
            else {
                $WeekRow += "{0,$PadDay} " -f $_
            }
        }
    
        $OutString = "$WeekRow".PadRight($PadRow, ' ')
        Write-Output $OutString
        #Write-Verbose "|$OutString| Week row length $($OutString.Length)"
    } # end process
}

function Get-Highlight {
    <# 
    .NOTES
        Helper function for Get-NCalendar and Get-Calendar. Returns an array with todays day if it is today as well
        as formatting strings.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Globalization.CultureInfo]$Culture,

        [Parameter(Mandatory, Position = 1)]
        [ValidateRange(1, 12)]
        [Int]$Month,
        
        [Parameter(Mandatory, Position = 2)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [Parameter(Position = 3)]
        [ValidateSet('None', 'Red', 'Green', 'Blue', 'Yellow', 'Cyan', 'Magenta', 'White', 'Orange', $null)]
        [String]$Highlight
    )
    $Now = Get-Today -Culture $Culture
    if ( ($Month -eq $Now.Month) -and ($Year -eq $Now.Year) ) {
        $Today = $Now.Day
    }
    else {
        $Today = 0
    }
    if (-not $Highlight) {
        # This is the default; reverse highlight today but no highlighted month name
        Write-Output @{
            Today    = $Today
            MonStyle = $null
            MonReset = $null
            DayStyle = $PSStyle.Reverse
            DayReset = $PSStyle.ReverseOff
        }
    }
    elseif ('None' -eq $Highlight) {
        # Turn off highlighting today
        Write-Output @{
            Today = 0
        }
    }
    elseif ('Orange' -eq $Highlight) {
        # To demonstrate a non-PSStyle supplied colour
        Write-Output @{
            Today    = $Today
            MonStyle = "$($PSStyle.Foreground.FromRgb(255,131,0))$($PSStyle.Bold)"
            MonReset = $PSStyle.Reset
            DayStyle = "$($PSStyle.Background.FromRgb(255,131,0))$($PSStyle.Foreground.FromRgb(0,0,0))"
            DayReset = $PSStyle.Reset
        }
    }
    else {
        # Force the bright version of the specified colour
        $Colour = "Bright$Highlight"
        Write-Output @{
            Today    = $Today
            MonStyle = "$($PSStyle.Foreground.$Colour)$($PSStyle.Bold)"
            MonReset = $PSStyle.Reset
            DayStyle = "$($PSStyle.Background.$Colour)$($PSStyle.Foreground.FromRgb(0,0,0))"
            DayReset = $PSStyle.Reset
        }
    }
}

function Get-NCalendar {
    <#
    .SYNOPSIS
        Get-NCalendar
    .DESCRIPTION
        This command displays calendar information similar to the Linux ncal command. It implements most of the
        same functionality, including the ability to display multiple months, years, week numbers, day of the year 
        and month forward and previous by one year.

        But in addition, the command can do a whole lot more:
        1. Display a calendar in any supported culture. Month and day names are displayed in the chosen culture, 
           and using the primary calendar used for each culture.
        2. Start of week can be selected (Friday through Monday). By default, the culture setting is used.
        3. Display abbreviated (default) or full day names, specific to the culture.
        4. Display one to six months in a row, when multiple months are displayed (the default is 4).
        5. When display week numbers, they will align correctly with the first day of the week.
        6. Highlighting the month headings, today and week numbers is possible.
        
        It is highly recommended that Windows Terminal is used with an appropriate font to ensure that ISO unicode
        character sets are both available and display properly. With one or two exceptions, all cultures align 
        correctly.

        Currently, 'Optional' calendars are not supported. These include the Julian, Hijra (Islamic), Chinese Lunar, 
        Hebrew and several other calendars which are not used primarily by any culture but are observed in many parts
        of the world for religious or scientific purposes.
    .PARAMETER Month
        Specifies the required month. This must be specified as a number 0..12. An 'f' (forward by one year) or a 'p' 
        (previous year) suffix can also be appended to the month number.
    .PARAMETER Year
        Specifies the required year. If no month is specified, the whole year is shown.
    .PARAMETER Culture
        Specifies the required culture. The system default culture is used by default.
    .PARAMETER FirstDayOfWeek
        Display the specified first day of the week. By default, the required culture is used to determine this.
    .PARAMETER MonthPerRow
        Display the specified number of months in each row. By default it is 4 months.
    .PARAMETER Highlight
        By default, today's date is highlighted. Specify a colour or disable the default highlight with 'none'.
    .PARAMETER Before
        The specified number of months are added before the specified month(s). See -After for examples.
    .PARAMETER After
        The specified number of months are added after the specified month(s). This is in addition to any date range 
        selected by the -Year or -Three options. For example, ncal -y 2021 -B 2 -A 2 will show from November 2020 to
        February 2022. Negative numbers are allowed, in which case the specified number of months is subtracted. For
        example, ncal -Y 2021 -B -6 shows July to December. Another example, ncal -A 11 simply shows the next 12 months.
    .PARAMETER Three
        Display the previous, current and next month surrounding the requested month. If -Year is also specified, this 
        parameter is ignored.
    .PARAMETER DayOfYear
        Display the day of the year (days one-based, numbered from 1st January).
    .PARAMETER Week
        Print the number of the week below each week column
    .PARAMETER LongDayName
        Display full day names for the required culture, instead of abbreviated day names.
    .EXAMPLE
        PS C:\> ncal
        
        Displays this month
    .EXAMPLE
        PS C:\> cal -m 1 -a 11
        
        Displays this year in any culture. for example, -y 2025 with cultures that do not use the Gregorian calendar
        by default will not work or produce unintended results. Some cultures use the Persian (Iranian), ThaiBuddist 
        and UmAlQura (Umm al-Qura, Saudi Arabian) calendars by default.
    .EXAMPLE
        PS C:\> ncal -m 1f

        Displays January next year. -m 1p shows January from the previous year
    .EXAMPLE
        PS C:\> ncal -m 4 -y 2021 -b 2 -a 1

        Displays April 2021 with the two months before and the month after it.
    .EXAMPLE
        PS C:\> ncal -y 2021 -a 24
        
        Shows 2021 through 2023
    .EXAMPLE
        PS C:\> ncal -j -three
        
        Show Julian days for last month, this month and next month
    .EXAMPLE
        PS C:\> ncal 2 2022 -three 
        
        Show February 2022 together with the month prior and month after.
    .EXAMPLE
        PS C:> ncal -Y 2021 -Highlight Red

        Shows the specified year with a highlighted colour. Supports red, blue, 
        green, yellow, orange, cyan, magenta and white. Disable all highlighting with 'none'.
    .INPUTS
        [System.String]
        [System.Int]
    .OUTPUTS
        [System.String]
    .NOTES
        Author: Roy Atkins
    #>
    [Alias('ncal')]
    [CmdletBinding()]
    param(
        # Could be integer between 1 and 12 or the same with an 'f' or 'p' suffix.
        [Parameter(Position = 0)]
        [Alias('m')]
        [String]$Month,

        [Parameter(Position = 1)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [Parameter(Position = 2)]
        [String]$Culture,

        [Parameter(Position = 3)]
        [ValidateSet('Friday', 'Saturday', 'Sunday', 'Monday')]
        [String]$FirstDayOfWeek,

        [Parameter(Position = 4)]
        [ValidateRange(1, 6)]
        [Int]$MonthPerRow = 4,

        [Parameter(Position = 5)]
        [ValidateSet('None', 'Red', 'Green', 'Blue', 'Yellow', 'Cyan', 'Magenta', 'White', 'Orange')]
        [String]$Highlight,

        [Int]$Before,

        [Int]$After,

        [Switch]$Three,

        [Switch]$DayOfYear,

        [Switch]$Week,

        [Switch]$LongDayName
    )

    begin {
        $Abort = $false
        if ($PSBoundParameters.ContainsKey('Culture')) {
            #$ThisCulture = [System.Globalization.CultureInfo]::CreateSpecificCulture($Culture)
            try {
                $ThisCulture = New-Object System.Globalization.CultureInfo($Culture) -ErrorAction Stop
            }
            catch {
                Write-Warning "ncal: Invalid culture specified:'$Culture'. Using the system default culture ($((Get-Culture).Name)). Use 'Get-Culture -ListAvailable'."
                $ThisCulture = [System.Globalization.CultureInfo]::CurrentCulture
            }
        }
        else {
            $ThisCulture = [System.Globalization.CultureInfo]::CurrentCulture
        }

        # Full month names in current culture
        $MonthNameArray = $ThisCulture.DateTimeFormat.MonthGenitiveNames

        <# 
            Instead of showing days of month, show days of the year. Linux ncal is wrong in referring to this as
            Julian Day, which is a continuous count of days from the start of the Julian Period (current Julian 
            Period started in 4713 BC). However, continue to use "Julian" because its more eye-catching than
            "DayOfYear".
        #>
        if ($PSBoundParameters.ContainsKey('DayOfYear')) {
            [Bool]$JulianSpecified = $true
        }
        else {
            [Bool]$JulianSpecified = $false
        }

        # List of abbreviated or long day names in the required order.
        if ($PSBoundParameters.ContainsKey('FirstDayOfWeek')) {
            $Param = @{
                'Culture'        = $ThisCulture
                'FirstDayOfWeek' = $FirstDayOfWeek
                'LongDayName'    = $LongDayName
            }
            $WeekDay = Get-WeekDayName @Param
        }
        else {
            $DefaultFirstDay = $ThisCulture.DateTimeFormat.FirstDayOfWeek
            $Param = @{
                'Culture'        = $ThisCulture
                'FirstDayOfWeek' = $DefaultFirstDay
                'LongDayName'    = $LongDayName
            }
            $WeekDay = Get-WeekDayName @Param
        }

        # Get the date of the first day of each required month, based on the culture (common to ncal & cal)
        $DateParam = New-Object -TypeName System.Collections.Hashtable
        $DateParam.Add('Culture', $ThisCulture)
        if ($PSBoundParameters.ContainsKey('Month')) {
            $DateParam.Add('Month', $Month)
        }
        if ($PSBoundParameters.ContainsKey('Year')) {
            $DateParam.Add('Year', $Year)
        }
        if ($PSBoundParameters.ContainsKey('Three')) {
            $DateParam.Add('Three', $Three)
        }
        if ($PSBoundParameters.ContainsKey('Before')) {
            $DateParam.Add('Before', $Before)
        }
        if ($PSBoundParameters.ContainsKey('After')) {
            $DateParam.Add('After', $After)
        }
        # this is where most parameter validation occurs, and most of the date conversion stuff.
        try {
            $MonthList = Get-FirstDayOfMonth @DateParam -ErrorAction Stop
        }
        catch {
            Write-Error $PSItem.Exception.Message
            $Abort = $true
        }

        # To hold each row of 1 to 6 months, initialized with culture specific day abbreviation
        [System.Collections.Generic.List[String]]$MonthRow = $WeekDay.Name
        $MonthCount = 0
        $MonthHeading = ' ' * $WeekDay.Offset
        $WeekRow = ' ' * ($WeekDay.Offset - 1)
    }
    process {
        foreach ($RequiredMonth in $MonthList) {
            if ($true -eq $Abort) {
                return
            }
            $ThisYear = $RequiredMonth.Year
            $ThisMonth = $RequiredMonth.Month
            $DayPerMonth = $RequiredMonth.DayPerMonth
            $FirstDayIndex = $RequiredMonth.FirstDayIndex
            $YearSpecified = $RequiredMonth.YearSpecified
            $MonthName = $MonthNameArray[$ThisMonth - 1]  # MonthNameArray is zero based
            if ($PSBoundParameters.ContainsKey('Three') -or $PSBoundParameters.ContainsKey('Month') -or $false -eq $YearSpecified) {
                $MonthName = "$MonthName $ThisYear"
            }

            # for highlighting today
            $Pretty = Get-Highlight $ThisCulture $ThisMonth $ThisYear $Highlight
            Write-Verbose "monthname = $MonthName, thismonth = $ThisMonth, thisyear = $ThisYear, dayspermonth = $DayPerMonth, monthcount = $MonthCount, culture = $($ThisCulture.Name)"

            # User specified First day of the week, or use the default for the culture being used.
            if ($PSBoundParameters.ContainsKey('FirstDayOfWeek')) {
                if ('Friday' -eq $FirstDayOfWeek) {
                    $StartWeekDay = 'Friday'
                }
                elseif ('Saturday' -eq $FirstDayOfWeek) {
                    $StartWeekDay = 'Saturday'
                }
                elseif ('Sunday' -eq $FirstDayOfWeek) {
                    $StartWeekDay = 'Sunday'
                }
                else {
                    $StartWeekDay = 'Monday'
                }
            }
            else {
                $StartWeekDay = $ThisCulture.DateTimeFormat.FirstDayOfWeek
            }

            # Get the starting index for the month, to offset when to start printing dates in the row.
            $Param = @{
                'Culture'       = $ThisCulture
                'StartWeekDay'  = $StartWeekDay
                'FirstDayIndex' = $FirstDayIndex
            }
            $ThisIndex = Get-StartWeekIndex @Param

            # User can choose number of months to print per row, default is 4. In this case, just append the month.
            if ($MonthCount -lt $MonthPerRow) {
                $Param = @{
                    'Culture'         = $ThisCulture
                    'MonthName'       = $MonthName
                    'JulianSpecified' = $JulianSpecified
                }
                $MonthHeading += "$(Get-MonthHeading @Param)"
                if ($PSBoundParameters.ContainsKey('Week')) {
                    $Param = @{
                        'Culture'         = $ThisCulture
                        'Month'           = $ThisMonth
                        'Year'            = $ThisYear
                        'FirstDayOfWeek'  = $StartWeekDay
                        'Index'           = $ThisIndex
                        'JulianSpecified' = $JulianSpecified
                    }
                    $WeekRow += Get-WeekRow @Param
                }
            }
            else {
                # Print a year heading before January when year is specified when the year is not already in month name
                if ($MonthHeading -match "\b$($MonthNameArray[0])\b" -and $MonthName -notmatch $ThisYear) {
                    $YearPad = (((18 * $MonthPerRow) + 3 - 2 ) / 2) + 2 
                    $YearHeading = "$ThisYear".PadLeft($YearPad, ' ')
                    Write-Output "$($Pretty.MonStyle)$YearHeading$($Pretty.MonReset)"
                }
                Write-Output "$($Pretty.MonStyle)$MonthHeading$($Pretty.MonReset)"
                Write-Output $MonthRow
                if ($PSBoundParameters.ContainsKey('Week')) {
                    Write-Output "$($Pretty.MonStyle)$WeekRow$($Pretty.MonReset)"
                }
                Write-Output ''

                # Reset for next row of months
                [System.Collections.Generic.List[String]]$MonthRow = $WeekDay.Name
                $MonthCount = 0
                $Param = @{
                    'Culture'         = $ThisCulture
                    'MonthName'       = $MonthName
                    'JulianSpecified' = $JulianSpecified
                }
                $MonthHeading = (' ' * $WeekDay.Offset) + "$(Get-MonthHeading @Param)"
                if ($PSBoundParameters.ContainsKey('Week')) {
                    $Param = @{
                        'Culture'         = $ThisCulture
                        'Month'           = $ThisMonth
                        'Year'            = $ThisYear
                        'FirstDayOfWeek'  = $StartWeekDay
                        'Index'           = $ThisIndex
                        'JulianSpecified' = $JulianSpecified
                    }
                    $WeekRow = Get-WeekRow @Param
                    
                    # starting padding for the week row is dependent on first week number
                    if (1 -eq "$WeekRow".Split(' ')[0].Length) {
                        $WeekRow = (' ' * $WeekDay.Offset) + $WeekRow
                    }
                    else {
                        $WeekRow = (' ' * ($WeekDay.Offset - 1)) + $WeekRow
                    }
                }
            }

            0..6 | ForEach-Object {
                $Param = @{
                    'Culture'         = $ThisCulture
                    'Index'           = $ThisIndex
                    'DayPerMonth'     = $DayPerMonth
                    'Month'           = $ThisMonth
                    'Year'            = $ThisYear
                    'Highlight'       = $Pretty
                    'JulianSpecified' = $JulianSpecified
                }
                $MonthRow[$_] += "$(Get-NcalRow @Param)"
                $ThisIndex++
            }
            $MonthCount++
        }
    }
    end {
        # Write the last month or row of months
        # Print a year heading before January when there is no year already in the month name.
        if (-Not $Abort) {
            if ($MonthHeading -match "\b$($MonthNameArray[0])\b" -and $MonthName -notmatch $ThisYear) {
                $YearPad = (((18 * $MonthPerRow) + 3 - 2 ) / 2) + 2 
                $YearHeading = "$ThisYear".PadLeft($YearPad, ' ')
                Write-Output "$($Pretty.MonStyle)$YearHeading$($Pretty.MonReset)"
            }
            Write-Output "$($Pretty.MonStyle)$MonthHeading$($Pretty.MonReset)"
            Write-Output $MonthRow
            if ($PSBoundParameters.ContainsKey('Week')) {
                Write-Output "$($Pretty.MonStyle)$WeekRow$($Pretty.MonReset)"
            }
        }
    }
}

function Get-Calendar {
    <#
    .SYNOPSIS
        Get-Calendar
    .DESCRIPTION
        This command displays calendar information similar to the Linux cal command. It implements most of the
        same functionality, including the ability to display multiple months, years, week numbers, day of the year 
        and month forward and previous by one year.

        But in addition, the command can do a whole lot more:
        1. Display a calendar in any supported culture. Month and day names are displayed in the chosen culture, 
           and using the primary calendar used for each culture.
        2. Start of week can be selected (Friday through Monday). By default, the chosen culture setting is used.
        3. Display one to six months in a row, when multiple months are displayed (the default is 3).
        4. Highlighting the month headings, today and week numbers is possible.
        
        It is highly recommended that Windows Terminal is used with an appropriate font to ensure that ISO unicode
        character sets are both available and display properly. With one or two exceptions, all cultures align 
        correctly.

        Currently, 'Optional' calendars are not supported. These include the Julian, Hijra (Islamic), Chinese Lunar, 
        Hebrew and several other calendars which are not used primarily by any culture but are observed in many parts
        of the world for religious or scientific purposes.
    .PARAMETER Month
        Specifies the required month. This must be specified as a number 0..12. An 'f' (forward by one year) or a 'p' 
        (previous year) suffix can also be appended to the month number.
    .PARAMETER Year
        Specifies the required year. If no month is specified, the whole year is shown.
    .PARAMETER Culture
        Specifies the required culture. The system default culture is used by default.
    .PARAMETER FirstDayOfWeek
        Display the specified first day of the week. By default, the required culture is used to determine this.
    .PARAMETER MonthPerRow
        Display the specified number of months in each row. By default it is 4 months.
    .PARAMETER Highlight
        By default, today's date is highlighted. Specify a colour or disable the default highlight with 'none'.
    .PARAMETER Before
        The specified number of months are added before the specified month(s). See -After for examples.
    .PARAMETER After
        The specified number of months are added after the specified month(s). This is in addition to any date range 
        selected by the -Year or -Three options. For example, ncal -y 2021 -B 2 -A 2 will show from November 2020 to
        February 2022. Negative numbers are allowed, in which case the specified number of months is subtracted. For
        example, ncal -Y 2021 -B -6 shows July to December. Another example, ncal -A 11 simply shows the next 12 months.
    .PARAMETER Three
        Display the previous, current and next month surrounding the requested month. If -Year is also specified, this 
        parameter is ignored.
    .PARAMETER DayOfYear
        Display the day of the year (days one-based, numbered from 1st January).
    .EXAMPLE
        PS C:\> cal
        
        Displays this month
    .EXAMPLE
        PS C:\> cal -m 1 -a 11
        
        Displays this year in any culture. for example, -y 2025 with cultures that do not use the Gregorian calendar
        by default will not work or produce unintended results. Some cultures use the Persian (Iranian), ThaiBuddist 
        and UmAlQura (Umm al-Qura, Saudi Arabian) calendars by default.
    .EXAMPLE
        PS C:\> cal -m 1f
        
        Displays January forward 1 year, Or January next year. -m 1p show January from previous year
    .EXAMPLE
        PS C:\> cal -m 4 -y 2021 -b 2 -a 1
        
        Displays April 2021 with the two months before and the month after it.
    .EXAMPLE
        PS C:\> cal -y 2021 -a 24
        
        Shows 2021 through 2023
    .EXAMPLE
        PS C:\> cal -j -three 
        
        Show Julian days for last month, this month and next month
    .EXAMPLE
        PS C:\> cal 2 2022 -three 
        
        Show February 2022 together with the month prior and month after.
    .EXAMPLE
        PS C:> cal -Y 2021 -Highlight Red

        Shows the specified year with a highlighted colour. Supports red, blue, green, yellow
        cyan, magenta and white. Disable all highlighting with 'none'.
    .INPUTS
        [System.String]
        [System.Int]
    .OUTPUTS
        [System.String]
    .NOTES
        Author: Roy Atkins
    #>
    [Alias('cal')]
    [CmdletBinding()]
    param(
        # Could be integer between 1 and 12 or the same with an 'f' or 'p' suffix.
        [Parameter(Position = 0)]
        [Alias('m')]
        [String]$Month,
        
        [Parameter(Position = 1)]
        [ValidateRange(1000, 9999)]
        [Int]$Year,

        [parameter(Position = 2)]
        [String]$Culture,

        [parameter(Position = 3)]
        [ValidateSet('Friday', 'Saturday', 'Sunday', 'Monday')]
        [String]$FirstDayOfWeek,

        [parameter(Position = 4)]
        [ValidateRange(1, 6)]
        [Int]$MonthPerRow = 3,

        [parameter(Position = 5)]
        [ValidateSet('None', 'Red', 'Green', 'Blue', 'Yellow', 'Cyan', 'Magenta', 'White', 'Orange')]
        [String]$Highlight,

        [Int]$Before,

        [Int]$After,

        [Switch]$Three,

        [Switch]$DayOfYear
    )

    begin {
        $Abort = $false
        if ($PSBoundParameters.ContainsKey('Culture')) {
            #$ThisCulture = [System.Globalization.CultureInfo]::CreateSpecificCulture($Culture)
            try {
                $ThisCulture = New-Object System.Globalization.CultureInfo($Culture) -ErrorAction Stop
            }
            catch {
                Write-Warning "ncal: Invalid culture specified:'$Culture'. Using the system default culture ($((Get-Culture).Name)). Use 'Get-Culture -ListAvailable'."
                $ThisCulture = [System.Globalization.CultureInfo]::CurrentCulture
            }
        }
        else {
            $ThisCulture = [System.Globalization.CultureInfo]::CurrentCulture
        }

        # Full month names in current culture
        $MonthNameArray = $ThisCulture.DateTimeFormat.MonthGenitiveNames

        <# 
            Instead of showing days of month, show days of the year. Linux cal is wrong in referring to this as
            Julian Day, which is a continuous count of days from the start of the Julian Period (current Julian 
            Period started in 4713 BC). However, continue to use "Julian" because its more eye-catching than
            "DayOfYear".
        #>
        if ($PSBoundParameters.ContainsKey('DayOfYear')) {
            [Bool]$JulianSpecified = $true
        }
        else {
            [Bool]$JulianSpecified = $false
        }

        # List of short day names in the required order.
        if ($PSBoundParameters.ContainsKey('FirstDayOfWeek')) {
            $Param = @{
                'Culture'         = $ThisCulture
                'FirstDayOfWeek'  = $FirstDayOfWeek
                'JulianSpecified' = $JulianSpecified
            }
            $WeekDay = Get-WeekDayName @Param
        }
        else {
            $DefaultFirstDay = $ThisCulture.DateTimeFormat.FirstDayOfWeek
            $Param = @{
                'Culture'         = $ThisCulture
                'FirstDayOfWeek'  = $DefaultFirstDay
                'JulianSpecified' = $JulianSpecified
            }
            $WeekDay = Get-WeekDayName @Param
        }

        # Get the date of the first day of each required month, based on the culture (common to ncal & cal)
        $DateParam = New-Object -TypeName System.Collections.Hashtable
        $DateParam.Add('Culture', $ThisCulture)
        if ($PSBoundParameters.ContainsKey('Month')) {
            $DateParam.Add('Month', $Month)
        }
        if ($PSBoundParameters.ContainsKey('Year')) {
            $DateParam.Add('Year', $Year)
        }
        if ($PSBoundParameters.ContainsKey('Three')) {
            $DateParam.Add('Three', $Three)
        }
        if ($PSBoundParameters.ContainsKey('Before')) {
            $DateParam.Add('Before', $Before)
        }
        if ($PSBoundParameters.ContainsKey('After')) {
            $DateParam.Add('After', $After)
        }
        # this is where most parameter validation occurs, and most of the date conversion stuff.
        try {
            $MonthList = Get-FirstDayOfMonth @DateParam -ErrorAction Stop
        }
        catch {
            Write-Error $PSItem.Exception.Message
            $Abort = $true
        }

        # initialize a strongly typed, fixed length array with no values.
        $MonthRow = New-Object -TypeName System.String[] -ArgumentList 7
        $MonthCount = 0
        $MonthHeading = ''
    }
    process {
        foreach ($RequiredMonth in $MonthList) {
            if ($true -eq $Abort) {
                return
            }
            $ThisYear = $RequiredMonth.Year
            $ThisMonth = $RequiredMonth.Month
            $DayPerMonth = $RequiredMonth.DayPerMonth
            $FirstDayIndex = $RequiredMonth.FirstDayIndex
            $YearSpecified = $RequiredMonth.YearSpecified
            $MonthName = $MonthNameArray[$ThisMonth - 1]  # MonthNameArray is zero based
            if ($PSBoundParameters.ContainsKey('Three') -or $PSBoundParameters.ContainsKey('Month') -or $false -eq $YearSpecified) {
                $MonthName = "$MonthName $ThisYear"
            }

            # for highlighting today
            $Pretty = Get-Highlight $ThisCulture $ThisMonth $ThisYear $Highlight
            Write-Verbose "monthname = $MonthName, thismonth = $ThisMonth, thisyear = $ThisYear, dayspermonth = $DayPerMonth, monthcount = $MonthCount, culture = $($ThisCulture.Name)"

            # User specified First day of the week, or use the default for the culture being used.
            if ($PSBoundParameters.ContainsKey('FirstDayOfWeek')) {
                if ('Friday' -eq $FirstDayOfWeek) {
                    $StartWeekDay = 'Friday'
                }
                elseif ('Saturday' -eq $FirstDayOfWeek) {
                    $StartWeekDay = 'Saturday'
                }
                elseif ('Sunday' -eq $FirstDayOfWeek) {
                    $StartWeekDay = 'Sunday'
                }
                else {
                    $StartWeekDay = 'Monday'
                }
            }
            else {
                $StartWeekDay = $ThisCulture.DateTimeFormat.FirstDayOfWeek
            }
            
            # Get the starting index for the month, to offset when to start printing dates in the row.
            $Param = @{
                'Culture'       = $ThisCulture
                'StartWeekDay'  = $StartWeekDay
                'FirstDayIndex' = $FirstDayIndex
            }
            $ThisIndex = Get-StartWeekIndex @Param

            # User can choose number of months to print per row, default is 3. In this case, just append the month.
            if ($MonthCount -lt $MonthPerRow) {
                $Param = @{
                    'Culture'         = $ThisCulture
                    'MonthName'       = $MonthName
                    'JulianSpecified' = $JulianSpecified
                }
                $MonthHeading += "$(Get-MonthHeading @Param)"
            }
            else {
                # Print a year heading before January when year is specified when the year is not already in month name
                if ($MonthHeading -match "\b$($MonthNameArray[0])\b" -and $MonthName -notmatch $ThisYear) {
                    $YearPad = (((22 * $MonthPerRow) - 2 ) / 2) + 2
                    $YearHeading = "$ThisYear".PadLeft($YearPad, ' ')
                    Write-Output "$($Pretty.MonStyle)$YearHeading$($Pretty.MonReset)"
                }
                Write-Output "$($Pretty.MonStyle)$MonthHeading$($Pretty.MonReset)"
                Write-Output $MonthRow
                Write-Output ''

                # Reset for next row of months
                $MonthRow = New-Object -TypeName System.String[] -ArgumentList 7
                $MonthCount = 0
                $Param = @{
                    'Culture'         = $ThisCulture
                    'MonthName'       = $MonthName
                    'JulianSpecified' = $JulianSpecified
                }
                $MonthHeading = "$(Get-MonthHeading @Param)"
            }

            $MonthRow[0] += "$($WeekDay.Name)" + '  '
            1..6 | ForEach-Object {
                $Param = @{
                    'Culture'         = $ThisCulture
                    'Index'           = $ThisIndex
                    'DayPerMonth'     = $DayPerMonth
                    'Month'           = $ThisMonth
                    'Year'            = $ThisYear
                    'Highlight'       = $Pretty
                    'JulianSpecified' = $JulianSpecified
                }
                $MonthRow[$_] += "$(Get-CalRow @Param)"
                $ThisIndex += 7
            }
            $MonthCount++
        }
    }

    end {
        # Write the last month or row of months
        # Print a year heading before Month 1 when year is specified
        if (-Not $Abort) {
            if ($MonthHeading -match "\b$($MonthNameArray[0])\b" -and $MonthName -notmatch $ThisYear) {
                $YearPad = (((22 * $MonthPerRow) - 2 ) / 2) + 2 
                $YearHeading = "$ThisYear".PadLeft($YearPad, ' ')
                Write-Output "$($Pretty.MonStyle)$YearHeading$($Pretty.MonReset)"
            }
            Write-Output "$($Pretty.MonStyle)$MonthHeading$($Pretty.MonReset)"
            Write-Output $MonthRow
        }
    }
}    
# SIG # Begin signature block
# MIIsDwYJKoZIhvcNAQcCoIIsADCCK/wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBgb+O9YKCiQxzj
# mPAtIDL/8kwxKNBF1AjM8K7KxTHH7qCCEXUwggVvMIIEV6ADAgECAhBI/JO0YFWU
# jTanyYqJ1pQWMA0GCSqGSIb3DQEBDAUAMHsxCzAJBgNVBAYTAkdCMRswGQYDVQQI
# DBJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcMB1NhbGZvcmQxGjAYBgNVBAoM
# EUNvbW9kbyBDQSBMaW1pdGVkMSEwHwYDVQQDDBhBQUEgQ2VydGlmaWNhdGUgU2Vy
# dmljZXMwHhcNMjEwNTI1MDAwMDAwWhcNMjgxMjMxMjM1OTU5WjBWMQswCQYDVQQG
# EwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS0wKwYDVQQDEyRTZWN0aWdv
# IFB1YmxpYyBDb2RlIFNpZ25pbmcgUm9vdCBSNDYwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQCN55QSIgQkdC7/FiMCkoq2rjaFrEfUI5ErPtx94jGgUW+s
# hJHjUoq14pbe0IdjJImK/+8Skzt9u7aKvb0Ffyeba2XTpQxpsbxJOZrxbW6q5KCD
# J9qaDStQ6Utbs7hkNqR+Sj2pcaths3OzPAsM79szV+W+NDfjlxtd/R8SPYIDdub7
# P2bSlDFp+m2zNKzBenjcklDyZMeqLQSrw2rq4C+np9xu1+j/2iGrQL+57g2extme
# me/G3h+pDHazJyCh1rr9gOcB0u/rgimVcI3/uxXP/tEPNqIuTzKQdEZrRzUTdwUz
# T2MuuC3hv2WnBGsY2HH6zAjybYmZELGt2z4s5KoYsMYHAXVn3m3pY2MeNn9pib6q
# RT5uWl+PoVvLnTCGMOgDs0DGDQ84zWeoU4j6uDBl+m/H5x2xg3RpPqzEaDux5mcz
# mrYI4IAFSEDu9oJkRqj1c7AGlfJsZZ+/VVscnFcax3hGfHCqlBuCF6yH6bbJDoEc
# QNYWFyn8XJwYK+pF9e+91WdPKF4F7pBMeufG9ND8+s0+MkYTIDaKBOq3qgdGnA2T
# OglmmVhcKaO5DKYwODzQRjY1fJy67sPV+Qp2+n4FG0DKkjXp1XrRtX8ArqmQqsV/
# AZwQsRb8zG4Y3G9i/qZQp7h7uJ0VP/4gDHXIIloTlRmQAOka1cKG8eOO7F/05QID
# AQABo4IBEjCCAQ4wHwYDVR0jBBgwFoAUoBEKIz6W8Qfs4q8p74Klf9AwpLQwHQYD
# VR0OBBYEFDLrkpr/NZZILyhAQnAgNpFcF4XmMA4GA1UdDwEB/wQEAwIBhjAPBgNV
# HRMBAf8EBTADAQH/MBMGA1UdJQQMMAoGCCsGAQUFBwMDMBsGA1UdIAQUMBIwBgYE
# VR0gADAIBgZngQwBBAEwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2NybC5jb21v
# ZG9jYS5jb20vQUFBQ2VydGlmaWNhdGVTZXJ2aWNlcy5jcmwwNAYIKwYBBQUHAQEE
# KDAmMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20wDQYJKoZI
# hvcNAQEMBQADggEBABK/oe+LdJqYRLhpRrWrJAoMpIpnuDqBv0WKfVIHqI0fTiGF
# OaNrXi0ghr8QuK55O1PNtPvYRL4G2VxjZ9RAFodEhnIq1jIV9RKDwvnhXRFAZ/ZC
# J3LFI+ICOBpMIOLbAffNRk8monxmwFE2tokCVMf8WPtsAO7+mKYulaEMUykfb9gZ
# pk+e96wJ6l2CxouvgKe9gUhShDHaMuwV5KZMPWw5c9QLhTkg4IUaaOGnSDip0TYl
# d8GNGRbFiExmfS9jzpjoad+sPKhdnckcW67Y8y90z7h+9teDnRGWYpquRRPaf9xH
# +9/DUp/mBlXpnYzyOmJRvOwkDynUWICE5EV7WtgwggXgMIIESKADAgECAhBe0Nem
# O8DFLKPUj+l9xr3tMA0GCSqGSIb3DQEBDAUAMFQxCzAJBgNVBAYTAkdCMRgwFgYD
# VQQKEw9TZWN0aWdvIExpbWl0ZWQxKzApBgNVBAMTIlNlY3RpZ28gUHVibGljIENv
# ZGUgU2lnbmluZyBDQSBSMzYwHhcNMjIwNjA3MDAwMDAwWhcNMjUwNjA2MjM1OTU5
# WjB3MQswCQYDVQQGEwJVUzEOMAwGA1UECAwFVGV4YXMxKzApBgNVBAoMIkhld2xl
# dHQgUGFja2FyZCBFbnRlcnByaXNlIENvbXBhbnkxKzApBgNVBAMMIkhld2xldHQg
# UGFja2FyZCBFbnRlcnByaXNlIENvbXBhbnkwggGiMA0GCSqGSIb3DQEBAQUAA4IB
# jwAwggGKAoIBgQC6ng2ELduVFspn7zNxeY/AS4Tij830RQECD/dUgsnqHOpnTX60
# CjMefSLxVsqkcIlD4V+deOiSs5JQDnupfshA6pV+tBiN1yWa3gTEX05RO2rYe7bc
# xD1vaitATa1FpZ6n0s1KWP4M1f+UaKMcE6CE4dlCu1KATOXCMD0scA8qj4ScBMZR
# mvZ4S8sNbwrQC5KpzOIHhQmiLRWEMGsDkyDXu6cCwPnsnHvEiNdX9mIBfMnARY5C
# 0oD2ul2lKnjyMgZCWStI7zWXf8P8hU8Ji73+Pep1jeyn3jd/Gveza0fow+wd1fdx
# 1+TS01bf054mbaipE5KKwqUD9XukKhsAEC+WLvTXMCGRpJZasSX2bKnR6ew0aEoX
# c9zQ0BKa4ZFbWbEPceyBOlQVB+2f53Wplrvh+8z1B4yifG/91clQLsP+UZJqzvhX
# E0cTcdb4aHaW/iHZQRAFdID0CBIHMNDTcYuaB+K961mvXYp+CxVDJF5kAT6W5KaM
# QNuooNWjk/rO9FkCAwEAAaOCAYkwggGFMB8GA1UdIwQYMBaAFA8qyyCHKLjsb0iu
# K1SmKaoXpM0MMB0GA1UdDgQWBBRsoQDhdo3sYBJ+aurMJLkY4RrLUDAOBgNVHQ8B
# Af8EBAMCB4AwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDAzBKBgNV
# HSAEQzBBMDUGDCsGAQQBsjEBAgEDAjAlMCMGCCsGAQUFBwIBFhdodHRwczovL3Nl
# Y3RpZ28uY29tL0NQUzAIBgZngQwBBAEwSQYDVR0fBEIwQDA+oDygOoY4aHR0cDov
# L2NybC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljQ29kZVNpZ25pbmdDQVIzNi5j
# cmwweQYIKwYBBQUHAQEEbTBrMEQGCCsGAQUFBzAChjhodHRwOi8vY3J0LnNlY3Rp
# Z28uY29tL1NlY3RpZ29QdWJsaWNDb2RlU2lnbmluZ0NBUjM2LmNydDAjBggrBgEF
# BQcwAYYXaHR0cDovL29jc3Auc2VjdGlnby5jb20wDQYJKoZIhvcNAQEMBQADggGB
# AGSOCQjjqdaLpLxf8u4P14ItH+lKoeDGsIgBPxOMwM4/BAElYOCW5XWzUTI+joRN
# zVi527GkhIrguRQrvS1q0xi9Sg/fTo/XyIMlW1/pssrwOuwUGw/LRSxpu50/Z0I8
# ZbHc55CbBSWC+LIskrxVvy+5nn1WMmyPaf1Hr/Fz2aUx/ILsGnR+vyPPRCaVV+0l
# dOpBuTkuN+fPwcf8lCIrADPyyujLf34MJHbBXhOjiTM9WSoROKGQUJBRufA+vMKr
# 45vPybW36vwMaMqPXLCfVQ/cXazuFZILmpmsn+6snKDkaLcBokZk7TPoKhSYrKLw
# vkPMChrd8vVxyaPAoEkQEOOGDkINNMmkjk2Y2I0XcrB4GiiLC2Vple0tOXH4MIku
# aWeIRxv+yELyNHLHj148LeN22FfucA2BPTbEH4YKOjw2Zbn1BP46QS0B3OlTGvwH
# 6Jsgh71kTGR695wFzcZLvtmInxzhnfZb5fmiSw1mG4rA86/r6x1EpXIN/s1c1q7D
# szCCBhowggQCoAMCAQICEGIdbQxSAZ47kHkVIIkhHAowDQYJKoZIhvcNAQEMBQAw
# VjELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEtMCsGA1UE
# AxMkU2VjdGlnbyBQdWJsaWMgQ29kZSBTaWduaW5nIFJvb3QgUjQ2MB4XDTIxMDMy
# MjAwMDAwMFoXDTM2MDMyMTIzNTk1OVowVDELMAkGA1UEBhMCR0IxGDAWBgNVBAoT
# D1NlY3RpZ28gTGltaXRlZDErMCkGA1UEAxMiU2VjdGlnbyBQdWJsaWMgQ29kZSBT
# aWduaW5nIENBIFIzNjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAJsr
# nVP6NT+OYAZDasDP9X/2yFNTGMjO02x+/FgHlRd5ZTMLER4ARkZsQ3hAyAKwktlQ
# qFZOGP/I+rLSJJmFeRno+DYDY1UOAWKA4xjMHY4qF2p9YZWhhbeFpPb09JNqFiTC
# Yy/Rv/zedt4QJuIxeFI61tqb7/foXT1/LW2wHyN79FXSYiTxcv+18Irpw+5gcTbX
# nDOsrSHVJYdPE9s+5iRF2Q/TlnCZGZOcA7n9qudjzeN43OE/TpKF2dGq1mVXn37z
# K/4oiETkgsyqA5lgAQ0c1f1IkOb6rGnhWqkHcxX+HnfKXjVodTmmV52L2UIFsf0l
# 4iQ0UgKJUc2RGarhOnG3B++OxR53LPys3J9AnL9o6zlviz5pzsgfrQH4lrtNUz4Q
# q/Va5MbBwuahTcWk4UxuY+PynPjgw9nV/35gRAhC3L81B3/bIaBb659+Vxn9kT2j
# Uztrkmep/aLb+4xJbKZHyvahAEx2XKHafkeKtjiMqcUf/2BG935A591GsllvWwID
# AQABo4IBZDCCAWAwHwYDVR0jBBgwFoAUMuuSmv81lkgvKEBCcCA2kVwXheYwHQYD
# VR0OBBYEFA8qyyCHKLjsb0iuK1SmKaoXpM0MMA4GA1UdDwEB/wQEAwIBhjASBgNV
# HRMBAf8ECDAGAQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBsGA1UdIAQUMBIw
# BgYEVR0gADAIBgZngQwBBAEwSwYDVR0fBEQwQjBAoD6gPIY6aHR0cDovL2NybC5z
# ZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljQ29kZVNpZ25pbmdSb290UjQ2LmNybDB7
# BggrBgEFBQcBAQRvMG0wRgYIKwYBBQUHMAKGOmh0dHA6Ly9jcnQuc2VjdGlnby5j
# b20vU2VjdGlnb1B1YmxpY0NvZGVTaWduaW5nUm9vdFI0Ni5wN2MwIwYIKwYBBQUH
# MAGGF2h0dHA6Ly9vY3NwLnNlY3RpZ28uY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAG
# /4Lhd2M2bnuhFSCbE/8E/ph1RGHDVpVx0ZE/haHrQECxyNbgcv2FymQ5PPmNS6Da
# h66dtgCjBsULYAor5wxxcgEPRl05pZOzI3IEGwwsepp+8iGsLKaVpL3z5CmgELIq
# mk/Q5zFgR1TSGmxqoEEhk60FqONzDn7D8p4W89h8sX+V1imaUb693TGqWp3T32IK
# GfIgy9jkd7GM7YCa2xulWfQ6E1xZtYNEX/ewGnp9ZeHPsNwwviJMBZL4xVd40uPW
# UnOJUoSiugaz0yWLODRtQxs5qU6E58KKmfHwJotl5WZ7nIQuDT0mWjwEx7zSM7fs
# 9Tx6N+Q/3+49qTtUvAQsrEAxwmzOTJ6Jp6uWmHCgrHW4dHM3ITpvG5Ipy62KyqYo
# vk5O6cC+040Si15KJpuQ9VJnbPvqYqfMB9nEKX/d2rd1Q3DiuDexMKCCQdJGpOqU
# sxLuCOuFOoGbO7Uv3RjUpY39jkkp0a+yls6tN85fJe+Y8voTnbPU1knpy24wUFBk
# fenBa+pRFHwCBB1QtS+vGNRhsceP3kSPNrrfN2sRzFYsNfrFaWz8YOdU254qNZQf
# d9O/VjxZ2Gjr3xgANHtM3HxfzPYF6/pKK8EE4dj66qKKtm2DTL1KFCg/OYJyfrdL
# Jq1q2/HXntgr2GVw+ZWhrWgMTn8v1SjZsLlrgIfZHDGCGfAwghnsAgEBMGgwVDEL
# MAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDErMCkGA1UEAxMi
# U2VjdGlnbyBQdWJsaWMgQ29kZSBTaWduaW5nIENBIFIzNgIQXtDXpjvAxSyj1I/p
# fca97TANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCDXyeLG/2fZ+jOVk7ziF7CV3zR+93Uq55zTBuS+fJCW
# hzANBgkqhkiG9w0BAQEFAASCAYByQnLTCZfKgGwfrg1UbkWjvhno6TWTqE1wL39o
# FangogLtB9edlKYJuOLzE4KVCKSSau8mtVN6Go5f5usL9xFYQwUQ36UtsNM1cpbC
# laULRz1SjR0O9614VtHBsjZairVqMOurZof1FTxlIYYyisPN+P0ahhWcOSZwOu9C
# 3DBxRtpSnznXazyWeeubm6O0GzWjENIbtPP6NwnlYDZzzHFOqRUiJXfae5x+46Wt
# odiGI6FxG6FzSKd6XyBfuvQ/IF+qJWB8LrQLpDaacdddKGE615MA1DvsTStd8REf
# 4iIZGLzdxx6/7aNK3z9oNQLzL3aZuptDS1aXDkTkYQHnqN0aiXmUW9sbZupSAcjx
# zC4FVzaN3Yylpwg4Yf6HByNraYsLqZyeynRs1NBKiQ8eKeMK9ToXwMKJ0rWFT24t
# E5/0iuBKgvCMpLg9hJVDjx4fCR6By7qenYdczPSI9aGsrn2tA2vMRmo6ioPvpwc7
# kpAPc3mCHIAC8V0XGsqfV8KTyXGhghdbMIIXVwYKKwYBBAGCNwMDATGCF0cwghdD
# BgkqhkiG9w0BBwKgghc0MIIXMAIBAzEPMA0GCWCGSAFlAwQCAgUAMIGIBgsqhkiG
# 9w0BCRABBKB5BHcwdQIBAQYJYIZIAYb9bAcBMEEwDQYJYIZIAWUDBAICBQAEMAog
# e1XwBv/c1C0fmoa45ieA0lwyGVw+yv50twhmbhceteWbcNcKTXap7TdGkF2/SgIR
# AKJmZYXQRGwYNetFC6Jl+iQYDzIwMjUwMjAxMDMzMzAxWqCCEwMwgga8MIIEpKAD
# AgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMxCzAJBgNVBAYT
# AlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQg
# VHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwHhcNMjQw
# OTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJVUzERMA8GA1UE
# ChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFtcCAyMDI0MIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauWMLpbbeZZo7Xo
# /ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL0J4L0HqVR1cz
# SzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9fpAT4BxpT9vJ
# oJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrbILRYynyEy7rS
# 1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3TTLHj1uhS66Y
# X2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R6HwX9QVpGnXP
# lKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8hyyADiX1xuTxK
# aXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+ShoOGLomMd3mJt
# 92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8zg3S7bk4QC4R
# rcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVANiav1k425zYy
# FMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XLln8mS8wWmdDL
# nBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQEAwIHgDAMBgNV
# HRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1UdIAQZMBcwCAYG
# Z4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUvcyl2mi91jGog
# j57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYDVR0fBFMwUTBP
# oE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYBBQUHAQEEgYMw
# gYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBYBggrBgEF
# BQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsF
# AAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZeq3jSi5GXeWP7
# xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew/L4tpqVNbSpW
# O9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH/6oMQAh078qR
# h6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3qF1P3xWvYViUJ
# Lsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+T6tptMUNlehS
# R7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/ZOB6b6Yum1Hv
# IiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp12aw8IQhhA/vE
# bFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5uHHdG6BoQau75
# KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc4pEVUNytmB3B
# pIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3HP50v/01ZHo/
# Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQwggauMIIElqAD
# AgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMjAz
# MjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBS
# U0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbSg9GeTKJtoLDM
# g/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9/UO0hNoR8XOx
# s+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXnHwZljZQp09ns
# ad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0VAshaG43IbtA
# rF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4fsbVYTXn+149z
# k6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40NjgHt1biclkJg6
# OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0QCirc0PO30qh
# HGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvvmz3+DrhkKvp1
# KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T/jnA+bIwpUzX
# 6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk42PgpuE+9sJ0
# sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5rmQzSM7TNsQID
# AQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUuhbZbU2F
# L3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08w
# DgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEB
# BGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsG
# AQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgG
# BmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAH1ZjsCTtm+Y
# qUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxpwc8dB+k+YMjY
# C+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIlzpVpP0d3+3J0
# FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQcAp876i8dU+6
# WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfeKuv2nrF5mYGj
# VoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+jSbl3ZpHxcpzp
# SwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJshIUDQtxMkzdwd
# eDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6OOmc4d0j/R0o
# 08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDwN7+YAN8gFk8n
# +2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR81fZvAT6gt4y
# 3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2VVQrH4D6wPIO
# K+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv
# 21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQD
# ExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcN
# MzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQg
# SW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2Vy
# dCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf
# 8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1
# mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe
# 7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecx
# y9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX
# 2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX
# 9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp49
# 3ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCq
# sWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFH
# dL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauG
# i0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYw
# DwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08w
# HwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGG
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0
# dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXn
# OF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23
# OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFI
# tJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7s
# pNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgi
# wbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cB
# qZ9Xql4o4rmUMYIDhjCCA4ICAQEwdzBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMO
# RGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNB
# NDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG+ekE4zMEMA0G
# CWCGSAFlAwQCAgUAoIHhMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkq
# hkiG9w0BCQUxDxcNMjUwMjAxMDMzMzAxWjArBgsqhkiG9w0BCRACDDEcMBowGDAW
# BBTb04XuYtvSPnvk9nFIUIck1YZbRTA3BgsqhkiG9w0BCRACLzEoMCYwJDAiBCB2
# dp+o8mMvH0MLOiMwrtZWdf7Xc9sF1mW5BZOYQ4+a2zA/BgkqhkiG9w0BCQQxMgQw
# 1SCH8K0JSXgoNn7uYPp12DW3oqSSNgSwSSPJODROWAzFbGdq0pMH5sgTfN1XFOFa
# MA0GCSqGSIb3DQEBAQUABIICAAN1stmAJvv+TyiVD+IU2ytyhdzSpljlKTQqR9Ft
# pJRhBxD2fToHTeKmpmX6upLV7eUYU8SJDfPpEpwabb4EW10Pk1NfWLlCbANKIkr8
# dvyTSpS4IYwogkmL8ba/d8k39M0ILD14NrLONAtcAEjRvZmNEJQVpUKb/aBgNbeT
# OYQ/+vjViwk49wRkM8SRuw+FZ98YR+Peg3ohjruLRZ06wFeiVOb1K+lQBBStvGiD
# jMhqrC6/i0CeuQGtHo+O3+GvgIEZWYKpq0Iyt2dbiCWpOQdQsHp30RRvtFlzKJ/s
# cpBJ7VHAD+Mkg2GTREOYd7o3Y3wISfD7kyTteW7uAWHL4VP7dMXHG72teH994tTo
# Z1GNKBB1ez1aflGyfzsW8VCO2HaPKkqb7BiydZzNu9HGSD94kncA9HLyCShpgxZK
# /fOMNEBhAs/fC2GM9DO3KPld/XIAUBxHH6m46IdvwjM16coGAvtJ9V11HZbbRD91
# DgZlJ5Y3JvLZ5f3sItJ85x8CGQA5FdcdMFikFYVVaUqO1l1VU++cVkL4Y6+TbBiR
# GZflly9JmBziaybJWwDa8LWDGj2YS101t8dOB5n/Flyc1P/oPBjzLJlj+nwE1NTx
# ejZEODJ6gGQVWkVUh9qL+K3APUyHLZrDuRk3yyU+gjV14McqYv1sAzcQzSbPl1e/
# enwG
# SIG # End signature block
